(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class='container-fluid'>\r\n    <div class='row'>\r\n        <div class='col body-content'>\r\n            <router-outlet></router-outlet>\r\n        </div>\r\n    </div>\r\n</div>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/config/config.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/config/config.component.html ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h1>Your tab is ready!</h1>\r\n<label style=\"padding-right:5px\" >Tab Name</label>\r\n<input placeholder=\"Question\" [(ngModel)]=\"tabName\"/>\r\n<p>Click 'Save' to proceed.</p>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.component.html":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.component.html ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!--<h1>loggedIn: {{authService.loggedIn}}</h1>-->\r\n\r\n<div *ngIf=\"!authService.loggedIn\">\r\n    <br />\r\n    <h2>Please sign in to continue</h2>\r\n    <button (click)=\"SignIn($event)\">Sign In</button>\r\n</div>\r\n\r\n\r\n<div *ngIf=\"authService.loggedIn\">\r\n    <!--<button (click)=\"SignOut($event)\">Sign Out</button>-->\r\n\r\n    <h3 class=\"teamsTitle\">Topic: {{currentTopic}} </h3>\r\n\r\n    <tabs>\r\n        <tab tabTitle=\"Unanswered Questions\" tabActive=\"true\">\r\n            <div id=\"unansweredCardDiv\" class=\"cardDiv card-body\">\r\n            </div>\r\n        </tab>\r\n        <tab tabTitle=\"Answered Questions\">\r\n            <div id=\"answeredCardDiv\" class=\"cardDiv card-body\">\r\n            </div>\r\n        </tab>\r\n    </tabs>\r\n</div>\r\n\r\n<!--<button class=\"filterCollapseButton\" (click)=\"showHideUnanswered($event)\">\r\n    <i [className]=\"unanswered_plusminus\"></i>\r\n    Unanswered\r\n</button>\r\n\r\n<div *ngIf=\"unansweredContentVisible\" id=\"unansweredCardDiv\"></div>\r\n\r\n\r\n<button class=\"filterCollapseButton\" (click)=\"showHideAnswered($event)\">\r\n    <i [className]=\"answered_plusminus\"></i>\r\n    Answered\r\n</button>\r\n\r\n<div *ngIf=\"answeredContentVisible\" id=\"answeredCardDiv\"></div>-->\r\n<!--<div id=\"accordion\">\r\n    <div class=\"card\">\r\n        <div class=\"card-header\" id=\"headingOne\">\r\n            <h5 class=\"mb-0\">\r\n                <button class=\"questionsCollapseButton btn btn-link\" data-toggle=\"collapse\" data-target=\"#collapseOne\" aria-expanded=\"true\" aria-controls=\"collapseOne\" (click)=\"showHideUnanswered($event)\">\r\n                    <i [ngClass]=\"{'plusminus fa': true,'fa-minus': unansweredContentVisible, 'fa-plus': !unansweredContentVisible}\"></i>\r\n                    Unanswered Questions\r\n                </button>\r\n            </h5>\r\n        </div>\r\n\r\n        <div id=\"collapseOne\" class=\"collapse show\" aria-labelledby=\"headingOne\">\r\n            <div id=\"unansweredCardDiv\" class=\"cardDiv card-body\">\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <div class=\"card\">\r\n        <div class=\"card-header\" id=\"headingTwo\">\r\n            <h5 class=\"mb-0\">\r\n                <button class=\"questionsCollapseButton btn btn-link collapsed\" data-toggle=\"collapse\" data-target=\"#collapseTwo\" aria-expanded=\"true\" aria-controls=\"collapseTwo\" (click)=\"showHideAnswered($event)\">\r\n                    <i [ngClass]=\"{'plusminus fa': true,'fa-minus': answeredContentVisible, 'fa-plus': !answeredContentVisible}\"></i>\r\n                    Answered Questions\r\n                </button>\r\n            </h5>\r\n        </div>\r\n        <div id=\"collapseTwo\" class=\"collapse show\" aria-labelledby=\"headingTwo\">\r\n            <div id=\"answeredCardDiv\" class=\"cardDiv card-body\">\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>-->\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/silent-end/silent-end.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/silent-end/silent-end.component.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/silent-start/silent-start.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/silent-start/silent-start.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("");

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".row {\r\n    padding:15px;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC9hcHAuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFlBQVk7QUFDaEIiLCJmaWxlIjoiYXBwL2FwcC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJvdyB7XHJcbiAgICBwYWRkaW5nOjE1cHg7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __importDefault(__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")).default]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule, getBaseUrl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBaseUrl", function() { return getBaseUrl; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _config_config_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./config/config.component */ "./src/app/config/config.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.service */ "./src/app/app.service.ts");
/* harmony import */ var _tabcontrol_tabs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./tabcontrol/tabs */ "./src/app/tabcontrol/tabs.ts");
/* harmony import */ var _tabcontrol_tab__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./tabcontrol/tab */ "./src/app/tabcontrol/tab.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./auth.service */ "./src/app/auth.service.ts");
/* harmony import */ var _silent_start_silent_start_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./silent-start/silent-start.component */ "./src/app/silent-start/silent-start.component.ts");
/* harmony import */ var _silent_end_silent_end_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./silent-end/silent-end.component */ "./src/app/silent-end/silent-end.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};















var appRoutes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component: _home_home_component__WEBPACK_IMPORTED_MODULE_7__["HomeComponent"] },
    { path: 'config', component: _config_config_component__WEBPACK_IMPORTED_MODULE_6__["ConfigComponent"] },
    { path: 'app-silent-start', component: _silent_start_silent_start_component__WEBPACK_IMPORTED_MODULE_13__["SilentStartComponent"] },
    { path: 'app-silent-end', component: _silent_end_silent_end_component__WEBPACK_IMPORTED_MODULE_14__["SilentEndComponent"] },
    { path: '**', component: _home_home_component__WEBPACK_IMPORTED_MODULE_7__["HomeComponent"] }
];
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"],
                _home_home_component__WEBPACK_IMPORTED_MODULE_7__["HomeComponent"],
                _config_config_component__WEBPACK_IMPORTED_MODULE_6__["ConfigComponent"],
                _silent_start_silent_start_component__WEBPACK_IMPORTED_MODULE_13__["SilentStartComponent"], _silent_end_silent_end_component__WEBPACK_IMPORTED_MODULE_14__["SilentEndComponent"],
                _tabcontrol_tabs__WEBPACK_IMPORTED_MODULE_9__["Tabs"], _tabcontrol_tab__WEBPACK_IMPORTED_MODULE_10__["Tab"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _angular_http__WEBPACK_IMPORTED_MODULE_3__["HttpModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(appRoutes), _angular_common_http__WEBPACK_IMPORTED_MODULE_11__["HttpClientModule"]
            ],
            providers: [{ provide: 'BASE_URL', useFactory: getBaseUrl }, _app_service__WEBPACK_IMPORTED_MODULE_8__["AppService"], _auth_service__WEBPACK_IMPORTED_MODULE_12__["AuthService"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());

function getBaseUrl() {
    return document.getElementsByTagName('base')[0].href;
}


/***/ }),

/***/ "./src/app/app.service.ts":
/*!********************************!*\
  !*** ./src/app/app.service.ts ***!
  \********************************/
/*! exports provided: AppService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppService", function() { return AppService; });
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auth.service */ "./src/app/auth.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};





var AppService = /** @class */ (function () {
    function AppService(http, baseUrl, authService) {
        this.authService = authService;
        this.http = http;
        this.baseUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiBaseUrl;
        this.setHeaders();
    }
    AppService.prototype.setHeaders = function () {
        var headers = new _angular_http__WEBPACK_IMPORTED_MODULE_0__["Headers"]({
            'Content-Type': 'application/json',
            'X-Frame-Options': 'SAMEORIGIN',
            'Authorization': 'Bearer ' + this.authService.token
        });
        this.options = new _angular_http__WEBPACK_IMPORTED_MODULE_0__["RequestOptions"]({ headers: headers });
    };
    AppService.prototype.getUserByUpn = function (upn) {
        return this.http.post(this.baseUrl + 'GetUserByUpn', JSON.stringify(upn), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getAllQuestions = function (tenantId) {
        return this.http.post(this.baseUrl + 'GetAllQuestions', JSON.stringify(tenantId), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.prototype.getQuestionsByGroup = function (groupId) {
        return this.http.post(this.baseUrl + 'GetQuestionsByGroup', JSON.stringify(groupId), this.options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res.json(); }));
    };
    AppService.ctorParameters = function () { return [
        { type: _angular_http__WEBPACK_IMPORTED_MODULE_0__["Http"] },
        { type: String, decorators: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"], args: ['BASE_URL',] }] },
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] }
    ]; };
    AppService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        __param(1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])('BASE_URL')),
        __metadata("design:paramtypes", [_angular_http__WEBPACK_IMPORTED_MODULE_0__["Http"], String, _auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]])
    ], AppService);
    return AppService;
}());



/***/ }),

/***/ "./src/app/auth.service.ts":
/*!*********************************!*\
  !*** ./src/app/auth.service.ts ***!
  \*********************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/teams-js */ "./node_modules/@microsoft/teams-js/dist/MicrosoftTeams.min.js");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! adal-angular/lib/adal */ "./node_modules/adal-angular/lib/adal.js");
/* harmony import */ var adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




var AuthService = /** @class */ (function () {
    function AuthService() {
        this.showSignInButton = false;
        this.loggedIn = false;
        this.config = {
            clientId: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.clientId,
            tenant: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.tenantId,
            // redirectUri must be in the list of redirect URLs for the Azure AD app
            redirectUri: window.location.origin + _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.redirectUri,
            cacheLocation: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.cacheLocation,
            navigateToLoginRequestUrl: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.navigateToLoginRequestUrl,
            popUp: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.popUp,
            extraQueryParameters: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.extraQueryParameters,
            postLogoutRedirectUri: window.location.origin
        };
    }
    AuthService.prototype.onAuthUpdate = function (fn) {
        this.loadNav = fn;
    };
    AuthService.prototype.getToken = function () {
        console.log("getToken");
        var context = new adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__(this.config);
        // try get cached token
        var token = context.getCachedToken(this.config.clientId);
        if (token) {
            // cache token success
            this.token = token;
            this.loggedIn = true;
            this.showSignInButton = false;
            console.log("token saved");
            this.loadNav();
        }
        else {
            console.log("no cachedToken");
            // No token, or token is expired
            var callback = (function (err1, idToken) {
                if (err1) {
                    // token renew fail
                    this.showSignInButton = true;
                    this.loggedIn = false;
                    console.log("renew fail: " + err1);
                }
                else {
                    // token renew success
                    this.token = idToken;
                    this.loggedIn = true;
                    this.showSignInButton = false;
                    console.log("renew success");
                    this.loadNav();
                }
            }).bind(this);
            context._renewIdToken(callback);
        }
    };
    AuthService.prototype.signOut = function () {
        var context = new adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__(this.config);
        context.logOut();
    };
    AuthService.prototype.signIn = function () {
        // try get token from AAD
        var context = new adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__(this.config);
        var signInSuccessCallback = (function (result) {
            // AuthenticationContext is a singleton
            var config = {
                clientId: this.config.clientId,
                tenant: this.config.tenantId,
                // redirectUri must be in the list of redirect URLs for the Azure AD app
                redirectUri: window.location.origin + this.config.redirectUri,
                cacheLocation: this.config.cacheLocation,
                navigateToLoginRequestUrl: this.config.navigateToLoginRequestUrl,
                extraQueryParameters: this.config.extraQueryParameters,
            };
            var context = new adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__(config);
            var idToken = context.getCachedToken(config.clientId);
            if (idToken) {
                this.showSignInButton = false;
                this.loggedIn = true;
                this.token = idToken;
                console.log("auth success");
                this.loadNav();
            }
            else {
                this.loggedIn = false;
                this.showSignInButton = true;
                console.log("auth success but no token");
            }
            ;
        }).bind(this);
        var signInFailCallback = (function (reason) {
            this.loggedIn = false;
            this.showSignInButton = true;
            console.log("Login failed: " + reason);
            if (reason === "CancelledByUser" || reason === "FailedToOpenWindow") {
                console.log("Login was blocked by popup blocker or canceled by user.");
            }
        }).bind(this);
        var msTeamsAuthenticate = (function () {
            _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["authentication"].authenticate({
                url: window.location.origin + _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.popUpUri,
                width: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.popUpWidth,
                height: _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.popUpHeight,
                successCallback: signInSuccessCallback,
                failureCallback: signInFailCallback
            });
        });
        var acquireTokencallback = (function (err, idToken) {
            // no token
            if (err) {
                console.log("acquire token failed: " + err);
                //context.login();
                _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["initialize"](msTeamsAuthenticate);
            }
            else {
                this.showSignInButton = false;
                this.loggedIn = true;
                this.token = idToken;
                console.log("acquire token success");
                this.loadNav();
            }
        }).bind(this);
        context.acquireToken(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].authConfig.instance, acquireTokencallback);
    };
    AuthService.prototype.onRenewSuccess = function (idToken) {
        // token renew success
        this.token = idToken;
        this.loggedIn = true;
        this.showSignInButton = false;
        console.log("renew success");
    };
    AuthService.prototype.onRenewFailure = function (err1) {
        // token renew fail
        this.showSignInButton = true;
        this.loggedIn = false;
        console.log("renew fail" + err1);
    };
    AuthService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], AuthService);
    return AuthService;
}());



/***/ }),

/***/ "./src/app/config/config.component.ts":
/*!********************************************!*\
  !*** ./src/app/config/config.component.ts ***!
  \********************************************/
/*! exports provided: ConfigComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigComponent", function() { return ConfigComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/teams-js */ "./node_modules/@microsoft/teams-js/dist/MicrosoftTeams.min.js");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};



var ConfigComponent = /** @class */ (function () {
    function ConfigComponent() {
        this.upn = "";
        this.tid = "";
        this.gid = "";
        this.cname = "";
        this.selfURL = "";
        this.tabName = "";
        this.selfURL = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].selfUrl;
        if (!this.selfURL.endsWith('/')) {
            this.selfURL += "/";
        }
    }
    ConfigComponent.prototype.ngOnInit = function () {
        var _this = this;
        console.log('ngOnInit');
        // initialize teams
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["initialize"]();
        // get context
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["getContext"](function (context) {
            console.log('getContext');
            _this.upn = context.upn;
            _this.tid = context.tid;
            _this.gid = context.groupId;
            _this.cname = context.channelName;
            _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["settings"].setValidityState(true);
        });
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["settings"].registerOnSaveHandler(function (saveEvent) {
            // Calculate host dynamically to enable local debugging
            console.log(_this.tabName);
            // Antares
            _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_1__["settings"].setSettings({
                contentUrl: _this.selfURL + "home?upn=" + _this.upn + "&tid=" + _this.tid + "&gid=" + _this.gid + "&cname=" + _this.cname,
                websiteUrl: _this.selfURL + "home?upn=" + _this.upn + "&tid=" + _this.tid + "&gid=" + _this.gid + "&cname=" + _this.cname,
                suggestedDisplayName: _this.tabName === "" ? "Questions" : _this.tabName,
                removeUrl: _this.selfURL + "remove",
                entityId: "1"
            });
            saveEvent.notifySuccess();
        });
    };
    ConfigComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'config',
            template: __importDefault(__webpack_require__(/*! raw-loader!./config.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/config/config.component.html")).default
        }),
        __metadata("design:paramtypes", [])
    ], ConfigComponent);
    return ConfigComponent;
}());



/***/ }),

/***/ "./src/app/home/home.component.ts":
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var adaptivecards__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! adaptivecards */ "./node_modules/adaptivecards/lib/adaptivecards.js");
/* harmony import */ var adaptivecards__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(adaptivecards__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var markdown_it__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! markdown-it */ "./node_modules/markdown-it/index.js");
/* harmony import */ var markdown_it__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(markdown_it__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment-timezone */ "./node_modules/moment-timezone/index.js");
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment_timezone__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../app.service */ "./src/app/app.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../auth.service */ "./src/app/auth.service.ts");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};








var HomeComponent = /** @class */ (function () {
    function HomeComponent(appService, route, authService) {
        this.authService = authService;
        this.answeredContentVisible = true;
        this.unansweredContentVisible = true;
        this.authService.onAuthUpdate(this.populateQuestions.bind(this));
        this.appService = appService;
        this.route = route;
        this.isIframe = window !== window.parent && !window.opener;
        var upnParam = this.route.snapshot.queryParamMap.get("upn");
        if (upnParam)
            src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn = upnParam;
        //console.log("upn: " + upn);
        var tidParam = this.route.snapshot.queryParamMap.get("tid");
        if (tidParam)
            src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].tid = tidParam;
        //console.log("tid: " + tid);
        var gidParam = this.route.snapshot.queryParamMap.get("gid");
        if (gidParam)
            src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].gid = gidParam;
        //console.log("gid: " + gid);
        var cnameParam = this.route.snapshot.queryParamMap.get("cname");
        if (cnameParam)
            src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].cname = cnameParam;
        //console.log("cname: " + cname);
        authService.getToken();
    }
    HomeComponent.prototype.ngOnInit = function () {
        // get teams context
        // initialize teams
    };
    HomeComponent.prototype.populateQuestions = function () {
        //alert("loggedIn: " + this.authService.loggedIn);
        var _this = this;
        this.appService.setHeaders();
        this.appService.getUserByUpn(src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].upn).subscribe(function (result) {
            _this.currentUser = result;
        }, function (error) { return console.error(error); });
        // get questions
        this.appService.getQuestionsByGroup(src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].gid).subscribe(function (result) {
            _this.questions = result;
            if (src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].cname.toLowerCase() == "general") {
                _this.currentTopic = "All";
            }
            else {
                _this.currentTopic = src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].cname;
                _this.questions = result.filter(function (x) { return x.topic.trim().toLowerCase() == _this.currentTopic.toLowerCase(); });
            }
            _this.unansweredQuestions = _this.questions
                .filter(function (x) { return x.questionStatus.trim() == "unanswered"; })
                .sort(function (a, b) { return new Date(b.questionSubmitted).getTime() - new Date(a.questionSubmitted).getTime(); });
            _this.answeredQuestions = _this.questions
                .filter(function (x) { return x.questionStatus.trim() == "answered"; })
                .sort(function (a, b) { return new Date(b.questionAnswered).getTime() - new Date(a.questionAnswered).getTime(); });
            // create cards --- performance??
            var cardHolderDiv;
            /*** UNANSWERED ***/
            var unansweredFragment = document.createDocumentFragment();
            if (_this.unansweredQuestions.length > 0) {
                // iterate over questions
                _this.unansweredQuestions.forEach(function (q) {
                    cardHolderDiv = document.createElement("div");
                    cardHolderDiv.setAttribute("id", "unansweredCardHolder");
                    cardHolderDiv.setAttribute("class", "cardHolder");
                    cardHolderDiv.appendChild(_this.createCard(q));
                    unansweredFragment.appendChild(cardHolderDiv);
                });
            }
            else {
                cardHolderDiv = document.createElement("div");
                cardHolderDiv.setAttribute("class", "cardHolder");
                cardHolderDiv.innerHTML = "<div style=\"padding: 10px;\">There are no unanswered questions.</div>";
                unansweredFragment.appendChild(cardHolderDiv);
            }
            // And finally insert it somewhere in your page:
            document.getElementById("unansweredCardDiv").appendChild(unansweredFragment);
            /*** ANSWERED ***/
            var answeredFragment = document.createDocumentFragment();
            if (_this.answeredQuestions.length > 0) {
                // iterate over questions
                _this.answeredQuestions.forEach(function (q) {
                    cardHolderDiv = document.createElement("div");
                    cardHolderDiv.setAttribute("id", "answeredCardHolder");
                    cardHolderDiv.setAttribute("class", "cardHolder");
                    cardHolderDiv.appendChild(_this.createCard(q));
                    answeredFragment.appendChild(cardHolderDiv);
                });
            }
            else {
                cardHolderDiv = document.createElement("div");
                cardHolderDiv.setAttribute("class", "cardHolder");
                cardHolderDiv.innerHTML = "<div style=\"padding: 10px;\">There are no answered questions.</div>";
                answeredFragment.appendChild(cardHolderDiv);
            }
            // And finally insert it somewhere in your page:
            document.getElementById("answeredCardDiv").appendChild(answeredFragment);
        }, function (error) { return console.error(error); });
    };
    HomeComponent.prototype.createCard = function (question) {
        var answerPosterName = "";
        if (question.answerPoster != null)
            answerPosterName = question.answerPoster.fullName;
        var cardUnanswered = {
            "$schema": "https://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "style": "emphasis",
            "body": [
                {
                    "type": "Container",
                    "items": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": question.topic,
                                            "size": "medium"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": question.questionText,
                                            "weight": "bolder",
                                            "wrap": true,
                                            "size": "medium"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": question.answerText,
                                            "weight": "bolder",
                                            "wrap": true,
                                            "size": "medium",
                                            "color": "good"
                                        }
                                    ]
                                },
                                {
                                    "type": "Column",
                                    "width": "auto",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Submitted: ",
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": question.originalPoster.fullName,
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "spacing": "none",
                                                            "text": moment_timezone__WEBPACK_IMPORTED_MODULE_3__["utc"](question.questionSubmitted).local().format("DD MMM YYYY, hh:mm a"),
                                                            "isSubtle": true,
                                                            "wrap": true
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ],
            "actions": [
                {
                    "type": "Action.OpenUrl",
                    "title": "View Conversation",
                    "url": question.link
                }
            ]
        };
        var cardAnswered = {
            "$schema": "https://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "style": "emphasis",
            "body": [
                {
                    "type": "Container",
                    "items": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "stretch",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": question.topic,
                                            "size": "medium"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": question.questionText,
                                            "weight": "bolder",
                                            "wrap": true,
                                            "size": "medium"
                                        },
                                        {
                                            "type": "TextBlock",
                                            "text": question.answerText,
                                            "weight": "bolder",
                                            "wrap": true,
                                            "size": "medium",
                                            "color": "good"
                                        }
                                    ]
                                },
                                {
                                    "type": "Column",
                                    "width": "auto",
                                    "items": [
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Submitted: ",
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": question.originalPoster.fullName,
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "spacing": "none",
                                                            "text": moment_timezone__WEBPACK_IMPORTED_MODULE_3__["utc"](question.questionSubmitted).local().format("DD MMM YYYY, hh:mm a"),
                                                            "isSubtle": true,
                                                            "wrap": true
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        {
                                            "type": "ColumnSet",
                                            "columns": [
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": "Answered:  ",
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        }
                                                    ]
                                                },
                                                {
                                                    "type": "Column",
                                                    "width": "auto",
                                                    "items": [
                                                        {
                                                            "type": "TextBlock",
                                                            "text": answerPosterName,
                                                            "weight": "bolder",
                                                            "wrap": true
                                                        },
                                                        {
                                                            "type": "TextBlock",
                                                            "spacing": "none",
                                                            "text": moment_timezone__WEBPACK_IMPORTED_MODULE_3__["utc"](question.questionAnswered).local().format("DD MMM YYYY, hh:mm a"),
                                                            "isSubtle": true,
                                                            "wrap": true
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ],
            "actions": [
                {
                    "type": "Action.OpenUrl",
                    "title": "View Conversation",
                    "url": question.link
                }
            ]
        };
        var cardUnansweredMobile = {
            "$schema": "https://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "style": "emphasis",
            "body": [
                {
                    "type": "Container",
                    "items": [
                        {
                            "type": "TextBlock",
                            "text": question.questionText,
                            "weight": "bolder",
                            "wrap": true,
                            "size": "small"
                        },
                        {
                            "type": "TextBlock",
                            "text": question.answerText,
                            "wrap": true,
                            "size": "small",
                            "color": "good"
                        },
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "auto",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": "Submitted: ",
                                            "weight": "bolder",
                                            "size": "small",
                                            "wrap": true
                                        }
                                    ]
                                },
                                {
                                    "type": "Column",
                                    "width": "auto",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "text": question.originalPoster.fullName,
                                            "size": "small",
                                            "wrap": true
                                        }
                                    ]
                                },
                                {
                                    "type": "Column",
                                    "width": "auto",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "spacing": "none",
                                            "size": "small",
                                            "text": moment_timezone__WEBPACK_IMPORTED_MODULE_3__["utc"](question.questionSubmitted).local().format("DD MMM YYYY, hh:mm a"),
                                            "isSubtle": true,
                                            "wrap": true
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ],
            "actions": [
                {
                    "type": "Action.OpenUrl",
                    "title": "View Conversation",
                    "url": question.link
                }
            ]
        };
        var cardAnsweredMobile = {
            "$schema": "https://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "style": "emphasis",
            "body": [
                {
                    "type": "TextBlock",
                    "text": question.questionText,
                    "weight": "bolder",
                    "wrap": true,
                    "size": "small"
                },
                {
                    "type": "TextBlock",
                    "text": question.answerText,
                    "wrap": true,
                    "size": "small",
                    "color": "good"
                },
                {
                    "type": "ColumnSet",
                    "columns": [
                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "text": "Submitted: ",
                                    "weight": "bolder",
                                    "size": "small",
                                    "wrap": true
                                }
                            ]
                        },
                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "text": question.originalPoster.fullName,
                                    "size": "small",
                                    "wrap": true
                                }
                            ]
                        },
                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "spacing": "none",
                                    "size": "small",
                                    "text": moment_timezone__WEBPACK_IMPORTED_MODULE_3__["utc"](question.questionSubmitted).local().format("DD MMM YYYY, hh:mm a"),
                                    "isSubtle": true,
                                    "wrap": true
                                }
                            ]
                        }
                    ]
                },
                {
                    "type": "ColumnSet",
                    "columns": [
                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "text": "Answered:  ",
                                    "weight": "bolder",
                                    "size": "small",
                                    "wrap": true
                                }
                            ]
                        },
                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "text": answerPosterName,
                                    "size": "small",
                                    "wrap": true
                                }
                            ]
                        },
                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "spacing": "none",
                                    "size": "small",
                                    "text": moment_timezone__WEBPACK_IMPORTED_MODULE_3__["utc"](question.questionAnswered).local().format("DD MMM YYYY, hh:mm a"),
                                    "isSubtle": true,
                                    "wrap": true
                                }
                            ]
                        }
                    ]
                }
            ],
            "actions": [
                {
                    "type": "Action.OpenUrl",
                    "title": "View Conversation",
                    "url": question.link
                }
            ]
        };
        // Create an AdaptiveCard instance
        var adaptiveCard = new adaptivecards__WEBPACK_IMPORTED_MODULE_1__["AdaptiveCard"]();
        // Set its hostConfig property unless you want to use the default Host Config
        // Host Config defines the style and behavior of a card
        adaptiveCard.hostConfig = new adaptivecards__WEBPACK_IMPORTED_MODULE_1__["HostConfig"]({
            "choiceSetInputValueSeparator": ",",
            "supportsInteractivity": true,
            "fontFamily": "Segoe UI",
            "spacing": {
                "small": 3,
                "default": 8,
                "medium": 20,
                "large": 30,
                "extraLarge": 40,
                "padding": 20
            },
            "separator": {
                "lineThickness": 1,
                "lineColor": "#EEEEEE"
            },
            "fontSizes": {
                "small": 12,
                "default": 14,
                "medium": 17,
                "large": 21,
                "extraLarge": 26
            },
            "fontWeights": {
                "lighter": 200,
                "default": 400,
                "bolder": 600
            },
            "imageSizes": {
                "small": 40,
                "medium": 80,
                "large": 160
            },
            "containerStyles": {
                "default": {
                    "foregroundColors": {
                        "default": {
                            "default": "#333333",
                            "subtle": "#EE333333"
                        },
                        "dark": {
                            "default": "#000000",
                            "subtle": "#66000000"
                        },
                        "light": {
                            "default": "#FFFFFF",
                            "subtle": "#33000000"
                        },
                        "accent": {
                            "default": "#2E89FC",
                            "subtle": "#882E89FC"
                        },
                        "good": {
                            "default": "#54a254",
                            "subtle": "#DD54a254"
                        },
                        "warning": {
                            "default": "#e69500",
                            "subtle": "#DDe69500"
                        },
                        "attention": {
                            "default": "#cc3300",
                            "subtle": "#DDcc3300"
                        }
                    },
                    "backgroundColor": "#00000000"
                },
                "emphasis": {
                    "foregroundColors": {
                        "default": {
                            "default": "#333333",
                            "subtle": "#EE333333"
                        },
                        "dark": {
                            "default": "#000000",
                            "subtle": "#66000000"
                        },
                        "light": {
                            "default": "#FFFFFF",
                            "subtle": "#33000000"
                        },
                        "accent": {
                            "default": "#2E89FC",
                            "subtle": "#882E89FC"
                        },
                        "good": {
                            "default": "#54a254",
                            "subtle": "#DD54a254"
                        },
                        "warning": {
                            "default": "#e69500",
                            "subtle": "#DDe69500"
                        },
                        "attention": {
                            "default": "#cc3300",
                            "subtle": "#DDcc3300"
                        }
                    },
                    "backgroundColor": "#08000000"
                }
            },
            "actions": {
                "maxActions": 5,
                "spacing": "Default",
                "buttonSpacing": 10,
                "showCard": {
                    "actionMode": "Inline",
                    "inlineTopMargin": 16,
                    "style": "emphasis"
                },
                "preExpandSingleShowCardAction": false,
                "actionsOrientation": "Horizontal",
                "actionAlignment": "Right"
            },
            "adaptiveCard": {
                "allowCustomStyle": false
            },
            "imageSet": {
                "imageSize": "Medium",
                "maxImageHeight": 100
            },
            "factSet": {
                "title": {
                    "size": "Default",
                    "color": "Default",
                    "isSubtle": false,
                    "weight": "Bolder",
                    "warp": true
                },
                "value": {
                    "size": "Default",
                    "color": "Default",
                    "isSubtle": false,
                    "weight": "Default",
                    "warp": true
                },
                "spacing": 10
            } // More host config options
        });
        // Set the adaptive card's event handlers. onExecuteAction is invoked
        // whenever an action is clicked in the card
        adaptiveCard.onExecuteAction = function (action) {
            window.open(action.url, "_blank");
        };
        // For markdown support
        adaptivecards__WEBPACK_IMPORTED_MODULE_1__["AdaptiveCard"].onProcessMarkdown = function (text) { return markdown_it__WEBPACK_IMPORTED_MODULE_2__().render(text); };
        // get screen size
        var width = (window.screen.width);
        if (width < 750) {
            // Parse the card payload
            if (question.questionAnswered)
                adaptiveCard.parse(cardAnsweredMobile);
            else
                adaptiveCard.parse(cardUnansweredMobile);
        }
        else {
            // Parse the card payload
            if (question.questionAnswered)
                adaptiveCard.parse(cardAnswered);
            else
                adaptiveCard.parse(cardUnanswered);
        }
        // Render the card to an HTML element:
        var renderedCard = adaptiveCard.render();
        return renderedCard;
    };
    HomeComponent.prototype.showHideUnanswered = function (event) {
        this.unansweredContentVisible = !this.unansweredContentVisible;
    };
    HomeComponent.prototype.showHideAnswered = function (event) {
        this.answeredContentVisible = !this.answeredContentVisible;
    };
    HomeComponent.prototype.SignIn = function (event) {
        this.authService.signIn();
    };
    HomeComponent.prototype.SignOut = function (event) {
        this.authService.signOut();
    };
    HomeComponent.ctorParameters = function () { return [
        { type: _app_service__WEBPACK_IMPORTED_MODULE_4__["AppService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
        { type: _auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"] }
    ]; };
    HomeComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'home',
            template: __importDefault(__webpack_require__(/*! raw-loader!./home.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.component.html")).default
        }),
        __metadata("design:paramtypes", [_app_service__WEBPACK_IMPORTED_MODULE_4__["AppService"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"], _auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"]])
    ], HomeComponent);
    return HomeComponent;
}());



/***/ }),

/***/ "./src/app/silent-end/silent-end.component.scss":
/*!******************************************************!*\
  !*** ./src/app/silent-end/silent-end.component.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAvc2lsZW50LWVuZC9zaWxlbnQtZW5kLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/silent-end/silent-end.component.ts":
/*!****************************************************!*\
  !*** ./src/app/silent-end/silent-end.component.ts ***!
  \****************************************************/
/*! exports provided: SilentEndComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SilentEndComponent", function() { return SilentEndComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var expose_loader_AuthenticationContext_node_modules_adal_angular_lib_adal_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! expose-loader?AuthenticationContext!../../../node_modules/adal-angular/lib/adal.js */ "./node_modules/expose-loader/index.js?AuthenticationContext!./node_modules/adal-angular/lib/adal.js-exposed");
/* harmony import */ var expose_loader_AuthenticationContext_node_modules_adal_angular_lib_adal_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(expose_loader_AuthenticationContext_node_modules_adal_angular_lib_adal_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! adal-angular/lib/adal */ "./node_modules/adal-angular/lib/adal.js");
/* harmony import */ var adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/teams-js */ "./node_modules/@microsoft/teams-js/dist/MicrosoftTeams.min.js");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

/// <reference path='../../../node_modules/@types/adal/index.d.ts' />


//let createAuthContextFn: adal.AuthenticationContextStatic = AuthenticationContext;


var SilentEndComponent = /** @class */ (function () {
    function SilentEndComponent() {
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__["initialize"](function () {
            var config = {
                clientId: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.clientId,
                tenant: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.tenantId,
                // redirectUri must be in the list of redirect URLs for the Azure AD app
                redirectUri: window.location.origin + src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.redirectUri,
                cacheLocation: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.cacheLocation,
                navigateToLoginRequestUrl: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.navigateToLoginRequestUrl,
            };
            var authContext = new adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__(config);
            if (authContext.isCallback(window.location.hash)) {
                authContext.handleWindowCallback();
                // Only call notifySuccess or notifyFailure if this page is in the authentication popup
                if (window.opener) {
                    if (authContext.getCachedUser()) {
                        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__["authentication"].notifySuccess();
                    }
                    else {
                        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__["authentication"].notifyFailure(authContext.getLoginError());
                    }
                }
            }
        });
    }
    SilentEndComponent.prototype.ngOnInit = function () {
    };
    SilentEndComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-silent-end',
            template: __importDefault(__webpack_require__(/*! raw-loader!./silent-end.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/silent-end/silent-end.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./silent-end.component.scss */ "./src/app/silent-end/silent-end.component.scss")).default]
        }),
        __metadata("design:paramtypes", [])
    ], SilentEndComponent);
    return SilentEndComponent;
}());



/***/ }),

/***/ "./src/app/silent-start/silent-start.component.scss":
/*!**********************************************************!*\
  !*** ./src/app/silent-start/silent-start.component.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAvc2lsZW50LXN0YXJ0L3NpbGVudC1zdGFydC5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/silent-start/silent-start.component.ts":
/*!********************************************************!*\
  !*** ./src/app/silent-start/silent-start.component.ts ***!
  \********************************************************/
/*! exports provided: SilentStartComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SilentStartComponent", function() { return SilentStartComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var expose_loader_AuthenticationContext_node_modules_adal_angular_lib_adal_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! expose-loader?AuthenticationContext!../../../node_modules/adal-angular/lib/adal.js */ "./node_modules/expose-loader/index.js?AuthenticationContext!./node_modules/adal-angular/lib/adal.js-exposed");
/* harmony import */ var expose_loader_AuthenticationContext_node_modules_adal_angular_lib_adal_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(expose_loader_AuthenticationContext_node_modules_adal_angular_lib_adal_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! adal-angular/lib/adal */ "./node_modules/adal-angular/lib/adal.js");
/* harmony import */ var adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/teams-js */ "./node_modules/@microsoft/teams-js/dist/MicrosoftTeams.min.js");
/* harmony import */ var _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

/// <reference path='../../../node_modules/@types/adal/index.d.ts' />




var SilentStartComponent = /** @class */ (function () {
    function SilentStartComponent() {
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__["initialize"]();
        // Get the tab context, and use the information to navigate to Azure AD login page
        _microsoft_teams_js__WEBPACK_IMPORTED_MODULE_3__["getContext"](function (context) {
            // ADAL.js configuration
            // Setup extra query parameters for ADAL
            // - openid and profile scope adds profile information to the id_token
            // - login_hint provides the expected user name
            var config = {
                clientId: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.clientId,
                tenant: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.tenantId,
                // redirectUri must be in the list of redirect URLs for the Azure AD app
                redirectUri: window.location.origin + src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.redirectUri,
                cacheLocation: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.cacheLocation,
                navigateToLoginRequestUrl: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.navigateToLoginRequestUrl,
                //popUp: true,
                extraQueryParameters: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].authConfig.extraQueryParameters,
                displayCall: null
            };
            if (context.upn) {
                config.extraQueryParameters = "scope=openid+profile&login_hint=" + encodeURIComponent(context.upn);
            }
            else {
                config.extraQueryParameters = "scope=openid+profile";
            }
            // Use a custom displayCall function to add extra query parameters to the url before navigating to it
            config.displayCall = function (urlNavigate) {
                if (urlNavigate) {
                    if (config.extraQueryParameters) {
                        urlNavigate += "&" + config.extraQueryParameters;
                    }
                    window.location.replace(urlNavigate);
                }
            };
            // Navigate to the AzureAD login page        
            var authContext = new adal_angular_lib_adal__WEBPACK_IMPORTED_MODULE_2__(config);
            authContext.login();
        });
    }
    SilentStartComponent.prototype.ngOnInit = function () {
    };
    SilentStartComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-silent-start',
            template: __importDefault(__webpack_require__(/*! raw-loader!./silent-start.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/silent-start/silent-start.component.html")).default,
            styles: [__importDefault(__webpack_require__(/*! ./silent-start.component.scss */ "./src/app/silent-start/silent-start.component.scss")).default]
        }),
        __metadata("design:paramtypes", [])
    ], SilentStartComponent);
    return SilentStartComponent;
}());



/***/ }),

/***/ "./src/app/tabcontrol/tab.ts":
/*!***********************************!*\
  !*** ./src/app/tabcontrol/tab.ts ***!
  \***********************************/
/*! exports provided: Tab */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab", function() { return Tab; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};

var Tab = /** @class */ (function () {
    function Tab() {
        this.active = false;
    }
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('tabTitle'),
        __metadata("design:type", String)
    ], Tab.prototype, "title", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])('tabActive'),
        __metadata("design:type", Object)
    ], Tab.prototype, "active", void 0);
    Tab = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'tab',
            template: "\n    <div [hidden]=\"!active\" class=\"pane\" style=\"padding:0px;\">\n      <ng-content></ng-content>\n    </div>\n  ",
            styles: ["\n    .pane{\n      padding: 1em;\n    }\n  "]
        })
    ], Tab);
    return Tab;
}());



/***/ }),

/***/ "./src/app/tabcontrol/tabs.ts":
/*!************************************!*\
  !*** ./src/app/tabcontrol/tabs.ts ***!
  \************************************/
/*! exports provided: Tabs */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tabs", function() { return Tabs; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _tab__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab */ "./src/app/tabcontrol/tab.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};


var Tabs = /** @class */ (function () {
    function Tabs() {
        this.changed = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    // contentChildren are set
    Tabs.prototype.ngAfterContentInit = function () {
        // get all active tabs
        //let activeTabs = this.tabs.filter((tab) => tab.active);
        //// if there is no active tab set, activate the first
        //if (activeTabs.length === 0) {
        //    this.selectTab(this.tabs.first);
        //}
    };
    Tabs.prototype.selectTab = function (tab) {
        // deactivate all tabs
        this.tabs.toArray().forEach(function (tab) { return tab.active = false; });
        // activate the tab the user has clicked on.
        tab.active = true;
        this.changed.emit(tab.title);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])('tabChanged'),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], Tabs.prototype, "changed", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ContentChildren"])(_tab__WEBPACK_IMPORTED_MODULE_1__["Tab"]),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["QueryList"])
    ], Tabs.prototype, "tabs", void 0);
    Tabs = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'tabs',
            template: "\n    <ul class=\"nav nav-tabs\">\n      <li *ngFor=\"let tab of tabs\" (click)=\"selectTab(tab)\" [class.active]=\"tab.active\">\n        <a href=\"#\" onclick=\"return false;\">{{tab.title}}</a>\n      </li>\n    </ul>\n    <ng-content></ng-content>\n  ",
        })
    ], Tabs);
    return Tabs;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};
var environment = {
    production: false,
    apiBaseUrl: "https://marjorie-hsd.azurewebsites.net/api/Request/",
    selfUrl: "https://marjorie-hsd-questions.azurewebsites.net",
    authConfig: {
        instance: "https://login.microsoftonline.com/",
        tenantId: "2bc2d6df-bd83-4beb-af4c-681767093733",
        clientId: "09f428be-cdc8-486d-8f8b-4c844480e70f",
        redirectUri: "/app-silent-end",
        cacheLocation: "localStorage",
        navigateToLoginRequestUrl: false,
        extraQueryParameters: "",
        popUp: true,
        popUpUri: "/app-silent-start",
        popUpWidth: 600,
        popUpHeight: 535
    },
    // do not populate the following:
    upn: "",
    tid: "",
    gid: "",
    cname: ""
};


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
var __importDefault = (undefined && undefined.__importDefault) || function (mod) {
  return (mod && mod.__esModule) ? mod : { "default": mod };
};




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\conrad_r\Source\Repos\Marjorie\Source\QuestionsTabApp\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map